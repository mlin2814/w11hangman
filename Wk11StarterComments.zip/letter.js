var Letter = function(let) {
	
// property to store the actual letter	

// property/boolean if the letter can be shown 

	this.letterRender = function() {
		//if appear is false then show the _
		//else appear is true then show character
	};
};

// export to use in word.js
